import { 
  AdminCategory, 
  AdminHostingPlan, 
  AdminUser, 
  AdminOrder, 
  AdminCoupon, 
  AdminSupportTicket 
} from '../types';
import { PaymentSettings } from './paymentSync';

// ==========================================
// Central SQLite Database API Client
// ==========================================

// ------------------------------------------
// Categories
// ------------------------------------------
export async function fetchCategoriesFromDb(): Promise<AdminCategory[]> {
  try {
    const res = await fetch('/api/categories', {
      headers: { 'Accept': 'application/json' },
      cache: 'no-cache'
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (json.success && Array.isArray(json.data)) return json.data;
  } catch (err) {
    console.warn('[SQLite API] Failed to fetch categories from server DB:', err);
  }
  return [];
}

export async function saveCategoryToDb(category: AdminCategory): Promise<AdminCategory | null> {
  try {
    const res = await fetch('/api/categories', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(category)
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (json.success && json.data) return json.data;
  } catch (err) {
    console.error('[SQLite API] Failed to create category in server DB:', err);
  }
  return null;
}

export async function updateCategoryInDb(id: string, updates: Partial<AdminCategory>): Promise<AdminCategory | null> {
  try {
    const res = await fetch(`/api/categories/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (json.success && json.data) return json.data;
  } catch (err) {
    console.error('[SQLite API] Failed to update category in server DB:', err);
  }
  return null;
}

export async function deleteCategoryFromDb(id: string): Promise<boolean> {
  try {
    const res = await fetch(`/api/categories/${encodeURIComponent(id)}`, {
      method: 'DELETE'
    });
    return res.ok;
  } catch (err) {
    console.error('[SQLite API] Failed to delete category from server DB:', err);
    return false;
  }
}

export async function syncCategoriesToDb(categories: AdminCategory[]): Promise<AdminCategory[]> {
  try {
    const res = await fetch('/api/categories', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(categories)
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (json.success && Array.isArray(json.data)) return json.data;
  } catch (err) {
    console.error('[SQLite API] Failed to sync categories to server DB:', err);
  }
  return categories;
}

// ------------------------------------------
// Plans
// ------------------------------------------
export async function fetchPlansFromDb(): Promise<AdminHostingPlan[]> {
  try {
    const res = await fetch('/api/plans', {
      headers: { 'Accept': 'application/json' },
      cache: 'no-cache'
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (json.success && Array.isArray(json.data)) return json.data;
  } catch (err) {
    console.warn('[SQLite API] Failed to fetch plans from server DB:', err);
  }
  return [];
}

export async function savePlanToDb(plan: AdminHostingPlan): Promise<AdminHostingPlan | null> {
  try {
    const res = await fetch('/api/plans', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(plan)
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (json.success && json.data) return json.data;
  } catch (err) {
    console.error('[SQLite API] Failed to create plan in server DB:', err);
  }
  return null;
}

export async function updatePlanInDb(id: string, updates: Partial<AdminHostingPlan>): Promise<AdminHostingPlan | null> {
  try {
    const res = await fetch(`/api/plans/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (json.success && json.data) return json.data;
  } catch (err) {
    console.error('[SQLite API] Failed to update plan in server DB:', err);
  }
  return null;
}

export async function deletePlanFromDb(id: string): Promise<boolean> {
  try {
    const res = await fetch(`/api/plans/${encodeURIComponent(id)}`, {
      method: 'DELETE'
    });
    return res.ok;
  } catch (err) {
    console.error('[SQLite API] Failed to delete plan from server DB:', err);
    return false;
  }
}

export async function syncPlansToDb(plans: AdminHostingPlan[]): Promise<AdminHostingPlan[]> {
  try {
    const res = await fetch('/api/plans', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(plans)
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (json.success && Array.isArray(json.data)) return json.data;
  } catch (err) {
    console.error('[SQLite API] Failed to sync plans to server DB:', err);
  }
  return plans;
}

// ------------------------------------------
// Users & Authentication
// ------------------------------------------
export async function fetchUsersFromDb(): Promise<AdminUser[]> {
  try {
    const res = await fetch('/api/users', {
      headers: { 'Accept': 'application/json' },
      cache: 'no-cache'
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (json.success && Array.isArray(json.data)) return json.data;
  } catch (err) {
    console.warn('[SQLite API] Failed to fetch users from server DB:', err);
  }
  return [];
}

export async function saveUserToDb(user: any): Promise<AdminUser | null> {
  try {
    const res = await fetch('/api/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(user)
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (json.success && json.data) return json.data;
  } catch (err) {
    console.error('[SQLite API] Failed to create user in server DB:', err);
  }
  return null;
}

export async function updateUserInDb(id: string, updates: Partial<AdminUser>): Promise<AdminUser | null> {
  try {
    const res = await fetch(`/api/users/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (json.success && json.data) return json.data;
  } catch (err) {
    console.error('[SQLite API] Failed to update user in server DB:', err);
  }
  return null;
}

export async function deleteUserFromDb(id: string): Promise<boolean> {
  try {
    const res = await fetch(`/api/users/${encodeURIComponent(id)}`, {
      method: 'DELETE'
    });
    return res.ok;
  } catch (err) {
    console.error('[SQLite API] Failed to delete user from server DB:', err);
    return false;
  }
}

export async function loginUserFromDb(identifier: string, password: string): Promise<{ success: boolean; user?: AdminUser; token?: string; error?: string }> {
  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ identifier, password })
    });
    const json = await res.json();
    return json;
  } catch (err: any) {
    return { success: false, error: err.message || 'Network error during login' };
  }
}

export async function registerUserInDb(data: { name: string; username: string; email: string; password: string }): Promise<{ success: boolean; user?: AdminUser; error?: string }> {
  try {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    const json = await res.json();
    return json;
  } catch (err: any) {
    return { success: false, error: err.message || 'Network error during registration' };
  }
}

export async function verifySessionFromDb(userId: string): Promise<{ success: boolean; user?: AdminUser }> {
  try {
    const res = await fetch('/api/auth/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId })
    });
    if (!res.ok) return { success: false };
    const json = await res.json();
    return json;
  } catch {
    return { success: false };
  }
}

// ------------------------------------------
// Orders
// ------------------------------------------
export async function fetchOrdersFromDb(userId?: string): Promise<AdminOrder[]> {
  try {
    const url = userId ? `/api/orders?userId=${encodeURIComponent(userId)}` : '/api/orders';
    const res = await fetch(url, {
      headers: { 'Accept': 'application/json' },
      cache: 'no-cache'
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (json.success && Array.isArray(json.data)) return json.data;
  } catch (err) {
    console.warn('[SQLite API] Failed to fetch orders from server DB:', err);
  }
  return [];
}

export async function saveOrderToDb(order: Partial<AdminOrder>): Promise<AdminOrder | null> {
  try {
    const res = await fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(order)
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (json.success && json.data) return json.data;
  } catch (err) {
    console.error('[SQLite API] Failed to create order in server DB:', err);
  }
  return null;
}

export async function updateOrderInDb(id: string, updates: Partial<AdminOrder>): Promise<AdminOrder | null> {
  try {
    const res = await fetch(`/api/orders/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (json.success && json.data) return json.data;
  } catch (err) {
    console.error('[SQLite API] Failed to update order in server DB:', err);
  }
  return null;
}

export async function deleteOrderFromDb(id: string): Promise<boolean> {
  try {
    const res = await fetch(`/api/orders/${encodeURIComponent(id)}`, {
      method: 'DELETE'
    });
    return res.ok;
  } catch (err) {
    console.error('[SQLite API] Failed to delete order from server DB:', err);
    return false;
  }
}

export async function syncOrdersToDb(orders: AdminOrder[]): Promise<AdminOrder[]> {
  try {
    const res = await fetch('/api/orders', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(orders)
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (json.success && Array.isArray(json.data)) return json.data;
  } catch (err) {
    console.error('[SQLite API] Failed to sync orders to server DB:', err);
  }
  return orders;
}

// ------------------------------------------
// Coupons
// ------------------------------------------
export async function fetchCouponsFromDb(): Promise<AdminCoupon[]> {
  try {
    const res = await fetch('/api/coupons', {
      headers: { 'Accept': 'application/json' },
      cache: 'no-cache'
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (json.success && Array.isArray(json.data)) return json.data;
  } catch (err) {
    console.warn('[SQLite API] Failed to fetch coupons from server DB:', err);
  }
  return [];
}

export async function saveCouponToDb(coupon: Partial<AdminCoupon>): Promise<AdminCoupon | null> {
  try {
    const res = await fetch('/api/coupons', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(coupon)
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (json.success && json.data) return json.data;
  } catch (err) {
    console.error('[SQLite API] Failed to create coupon in server DB:', err);
  }
  return null;
}

export async function updateCouponInDb(id: string, updates: Partial<AdminCoupon>): Promise<AdminCoupon | null> {
  try {
    const res = await fetch(`/api/coupons/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (json.success && json.data) return json.data;
  } catch (err) {
    console.error('[SQLite API] Failed to update coupon in server DB:', err);
  }
  return null;
}

export async function deleteCouponFromDb(id: string): Promise<boolean> {
  try {
    const res = await fetch(`/api/coupons/${encodeURIComponent(id)}`, {
      method: 'DELETE'
    });
    return res.ok;
  } catch (err) {
    console.error('[SQLite API] Failed to delete coupon from server DB:', err);
    return false;
  }
}

export async function validateCouponInDb(params: { code: string; orderAmount: number; userId?: string }): Promise<{
  valid: boolean;
  error?: string;
  coupon?: AdminCoupon;
  discountAmount: number;
  finalPrice: number;
}> {
  try {
    const res = await fetch('/api/coupons/validate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params)
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    return json;
  } catch (err: any) {
    return {
      valid: false,
      error: err.message || 'Validation request failed',
      discountAmount: 0,
      finalPrice: params.orderAmount
    };
  }
}

// ------------------------------------------
// Payment Settings
// ------------------------------------------
export async function fetchPaymentSettingsFromDb(): Promise<PaymentSettings | null> {
  try {
    const res = await fetch('/api/payment-settings', {
      headers: { 'Accept': 'application/json' },
      cache: 'no-cache'
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (json.success && json.data) return json.data;
  } catch (err) {
    console.warn('[SQLite API] Failed to fetch payment settings from server DB:', err);
  }
  return null;
}

export async function savePaymentSettingsToDb(settings: PaymentSettings): Promise<PaymentSettings | null> {
  try {
    const res = await fetch('/api/payment-settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings)
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (json.success && json.data) return json.data;
  } catch (err) {
    console.error('[SQLite API] Failed to save payment settings to server DB:', err);
  }
  return null;
}

// ------------------------------------------
// Tickets
// ------------------------------------------
export async function fetchTicketsFromDb(userEmail?: string): Promise<AdminSupportTicket[]> {
  try {
    const url = userEmail ? `/api/tickets?userEmail=${encodeURIComponent(userEmail)}` : '/api/tickets';
    const res = await fetch(url, {
      headers: { 'Accept': 'application/json' },
      cache: 'no-cache'
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (json.success && Array.isArray(json.data)) return json.data;
  } catch (err) {
    console.warn('[SQLite API] Failed to fetch tickets from server DB:', err);
  }
  return [];
}

export async function saveTicketToDb(ticket: AdminSupportTicket): Promise<AdminSupportTicket | null> {
  try {
    const res = await fetch('/api/tickets', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(ticket)
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (json.success && json.data) return json.data;
  } catch (err) {
    console.error('[SQLite API] Failed to save ticket to server DB:', err);
  }
  return null;
}

export async function updateTicketInDb(id: string, updates: Partial<AdminSupportTicket>): Promise<AdminSupportTicket | null> {
  try {
    const res = await fetch(`/api/tickets/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (json.success && json.data) return json.data;
  } catch (err) {
    console.error('[SQLite API] Failed to update ticket in server DB:', err);
  }
  return null;
}

export async function deleteTicketFromDb(id: string): Promise<boolean> {
  try {
    const res = await fetch(`/api/tickets/${encodeURIComponent(id)}`, {
      method: 'DELETE'
    });
    return res.ok;
  } catch (err) {
    console.error('[SQLite API] Failed to delete ticket from server DB:', err);
    return false;
  }
}
