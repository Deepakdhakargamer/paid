import type { Plugin } from 'vite';

/**
 * Safe API plugin — does NOT load better-sqlite3 (avoids native segfaults).
 *
 * All /api/* routes return a clear JSON response so the frontend falls back
 * to localStorage / seed data. Admin login still works via client-side seed:
 *   username: admin
 *   password: Admin@123
 *
 * To re-enable SQLite later (after fixing native module):
 *   1. npm rebuild better-sqlite3
 *   2. Set env ENABLE_SQLITE=1
 *   3. Restore the full plugin from git history
 */

function sendJson(res: any, statusCode: number, data: any) {
  res.statusCode = statusCode;
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.end(JSON.stringify(data));
}

export function sqliteApiPlugin(): Plugin {
  return {
    name: 'autocraft-sqlite-api',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        const url = req.url || '';

        if (!url.startsWith('/api/')) {
          return next();
        }

        // Never load better-sqlite3 — always return a soft failure
        // so the React client uses its localStorage / seed fallbacks.
        return sendJson(res, 503, {
          success: false,
          error: 'Network error: SQLite API disabled (native module unsafe). Using client-side fallback.',
        });
      });
    },
  };
}
