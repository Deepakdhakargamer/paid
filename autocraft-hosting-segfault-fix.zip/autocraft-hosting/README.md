# AUTOCRAFT Hosting

Premium, modern, fully animated cloud and game hosting provider for Minecraft, VPS, Discord bots, and dedicated servers.

## Run Locally

**Prerequisites:** Node.js 18+

1. Install dependencies:
   ```bash
   npm install
   ```

2. (Optional) Set the `GEMINI_API_KEY` in `.env.local` if using AI features.

3. Run the app:
   ```bash
   npm run dev
   ```

The app will be available at http://localhost:3000

## Default Admin Login

- Email / Username: `admin@autocraft.com` or `admin`
- Password: `Admin@123`

## Features

- Public marketing site with plans, services, team, live status
- User authentication (login / register)
- User dashboard (profile, tickets, orders)
- Full admin panel (plans, categories, staff, tickets, payments, coupons, orders)
- SQLite-backed persistence
- Checkout with UPI payment support

## Tech Stack

- React 19 + TypeScript
- Vite 6
- Tailwind CSS 4
- Motion (animations)
- better-sqlite3
- Lucide icons
