import { getDatabase } from './sqlite';
import { AdminCoupon, CouponUsageRecord } from '../types';

function rowToCoupon(row: any): AdminCoupon {
  let usedBy: CouponUsageRecord[] = [];
  try {
    usedBy = JSON.parse(row.usedBy || '[]');
  } catch {
    usedBy = [];
  }

  return {
    id: row.id,
    code: row.code,
    description: row.description || '',
    discountType: row.discountType === 'fixed' ? 'fixed' : 'percentage',
    discountValue: Number(row.discountValue) || 0,
    minOrderAmount: row.minOrderAmount ? Number(row.minOrderAmount) : undefined,
    maxDiscountAmount: row.maxDiscountAmount ? Number(row.maxDiscountAmount) : undefined,
    usageLimit: row.usageLimit ? Number(row.usageLimit) : undefined,
    perUserLimit: row.perUserLimit ? Number(row.perUserLimit) : undefined,
    startDate: row.startDate || undefined,
    expiryDate: row.expiryDate || undefined,
    active: Boolean(row.active),
    usesCount: Number(row.usesCount) || 0,
    usedBy,
    createdAt: row.createdAt || new Date().toISOString(),
    updatedAt: row.updatedAt || new Date().toISOString()
  };
}

export async function getAllCoupons(): Promise<AdminCoupon[]> {
  const db = getDatabase();
  const rows = db.prepare('SELECT * FROM coupons ORDER BY createdAt DESC').all();
  return rows.map(rowToCoupon);
}

export async function getCouponById(id: string): Promise<AdminCoupon | null> {
  const db = getDatabase();
  const row = db.prepare('SELECT * FROM coupons WHERE id = ?').get(id);
  return row ? rowToCoupon(row) : null;
}

export async function getCouponByCode(code: string): Promise<AdminCoupon | null> {
  const db = getDatabase();
  const clean = (code || '').trim().toUpperCase();
  const row = db.prepare('SELECT * FROM coupons WHERE upper(code) = ?').get(clean);
  return row ? rowToCoupon(row) : null;
}

export async function createCoupon(data: Partial<AdminCoupon> & { code: string; discountValue: number }): Promise<AdminCoupon> {
  const db = getDatabase();
  const cleanCode = data.code.trim().toUpperCase();
  const id = data.id || `cpn-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 7)}`;

  const stmt = db.prepare(`
    INSERT INTO coupons (
      id, code, description, discountType, discountValue, minOrderAmount, maxDiscountAmount,
      usageLimit, perUserLimit, startDate, expiryDate, active, usesCount, usedBy, createdAt, updatedAt
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?,
      ?, ?, ?, ?, ?, 0, '[]', datetime('now'), datetime('now')
    )
  `);

  stmt.run(
    id,
    cleanCode,
    data.description || '',
    data.discountType || 'percentage',
    Number(data.discountValue) || 0,
    data.minOrderAmount ? Number(data.minOrderAmount) : 0,
    data.maxDiscountAmount ? Number(data.maxDiscountAmount) : 0,
    data.usageLimit ? Number(data.usageLimit) : 100,
    data.perUserLimit ? Number(data.perUserLimit) : 1,
    data.startDate || null,
    data.expiryDate || null,
    data.active !== undefined ? (data.active ? 1 : 0) : 1
  );

  return (await getCouponById(id))!;
}

export async function updateCoupon(id: string, updates: Partial<AdminCoupon>): Promise<AdminCoupon | null> {
  const db = getDatabase();
  const current = await getCouponById(id);
  if (!current) return null;

  const merged = { ...current, ...updates };

  const stmt = db.prepare(`
    UPDATE coupons SET
      code = ?,
      description = ?,
      discountType = ?,
      discountValue = ?,
      minOrderAmount = ?,
      maxDiscountAmount = ?,
      usageLimit = ?,
      perUserLimit = ?,
      startDate = ?,
      expiryDate = ?,
      active = ?,
      usesCount = ?,
      usedBy = ?,
      updatedAt = datetime('now')
    WHERE id = ?
  `);

  stmt.run(
    merged.code.trim().toUpperCase(),
    merged.description || '',
    merged.discountType,
    Number(merged.discountValue) || 0,
    merged.minOrderAmount ? Number(merged.minOrderAmount) : 0,
    merged.maxDiscountAmount ? Number(merged.maxDiscountAmount) : 0,
    merged.usageLimit ? Number(merged.usageLimit) : 100,
    merged.perUserLimit ? Number(merged.perUserLimit) : 1,
    merged.startDate || null,
    merged.expiryDate || null,
    merged.active ? 1 : 0,
    Number(merged.usesCount) || 0,
    JSON.stringify(merged.usedBy || []),
    id
  );

  return await getCouponById(id);
}

export async function deleteCoupon(id: string): Promise<boolean> {
  const db = getDatabase();
  db.prepare('DELETE FROM coupons WHERE id = ?').run(id);
  return true;
}

export async function validateCoupon(params: {
  code: string;
  orderAmount: number;
  userId?: string;
}): Promise<{
  valid: boolean;
  error?: string;
  coupon?: AdminCoupon;
  discountAmount: number;
  finalPrice: number;
}> {
  const { code, orderAmount, userId } = params;
  const cleanCode = (code || '').trim().toUpperCase();

  if (!cleanCode) {
    return {
      valid: false,
      error: 'Please enter a coupon code.',
      discountAmount: 0,
      finalPrice: orderAmount
    };
  }

  const coupon = await getCouponByCode(cleanCode);
  if (!coupon) {
    return {
      valid: false,
      error: 'Invalid coupon code',
      discountAmount: 0,
      finalPrice: orderAmount
    };
  }

  if (!coupon.active) {
    return {
      valid: false,
      error: 'Coupon is not active',
      discountAmount: 0,
      finalPrice: orderAmount
    };
  }

  const now = new Date();

  if (coupon.startDate) {
    const start = new Date(coupon.startDate);
    if (now < start) {
      return {
        valid: false,
        error: 'Coupon has not started yet',
        discountAmount: 0,
        finalPrice: orderAmount
      };
    }
  }

  if (coupon.expiryDate) {
    const expiry = new Date(coupon.expiryDate);
    if (coupon.expiryDate.length === 10) {
      expiry.setHours(23, 59, 59, 999);
    }
    if (now > expiry) {
      return {
        valid: false,
        error: 'Coupon has expired',
        discountAmount: 0,
        finalPrice: orderAmount
      };
    }
  }

  if (coupon.usageLimit && coupon.usageLimit > 0) {
    if (coupon.usesCount >= coupon.usageLimit) {
      return {
        valid: false,
        error: 'Coupon usage limit has been reached',
        discountAmount: 0,
        finalPrice: orderAmount
      };
    }
  }

  if (userId && coupon.perUserLimit && coupon.perUserLimit > 0) {
    const userUses = (coupon.usedBy || []).filter(u => u.userId === userId).length;
    if (userUses >= coupon.perUserLimit) {
      return {
        valid: false,
        error: `You have already used this coupon the maximum allowed times (${coupon.perUserLimit}).`,
        discountAmount: 0,
        finalPrice: orderAmount
      };
    }
  }

  if (coupon.minOrderAmount && coupon.minOrderAmount > 0) {
    if (orderAmount < coupon.minOrderAmount) {
      return {
        valid: false,
        error: `Minimum order amount for this coupon is ₹${coupon.minOrderAmount}.`,
        discountAmount: 0,
        finalPrice: orderAmount
      };
    }
  }

  let calculatedDiscount = 0;
  if (coupon.discountType === 'percentage') {
    calculatedDiscount = (orderAmount * coupon.discountValue) / 100;
    if (coupon.maxDiscountAmount && coupon.maxDiscountAmount > 0) {
      calculatedDiscount = Math.min(calculatedDiscount, coupon.maxDiscountAmount);
    }
  } else {
    calculatedDiscount = coupon.discountValue;
  }

  calculatedDiscount = Math.min(calculatedDiscount, orderAmount);
  calculatedDiscount = Math.round(calculatedDiscount * 100) / 100;

  const finalPrice = Math.max(0, Math.round((orderAmount - calculatedDiscount) * 100) / 100);

  return {
    valid: true,
    coupon,
    discountAmount: calculatedDiscount,
    finalPrice
  };
}

export async function recordCouponUsage(params: {
  couponId?: string;
  couponCode?: string;
  orderId: string;
  userId?: string;
  userEmail?: string;
  discountApplied: number;
}): Promise<boolean> {
  let coupon: AdminCoupon | null = null;
  if (params.couponId) coupon = await getCouponById(params.couponId);
  if (!coupon && params.couponCode) coupon = await getCouponByCode(params.couponCode);
  if (!coupon) return false;

  const newRecord: CouponUsageRecord = {
    userId: params.userId || 'guest',
    userEmail: params.userEmail,
    orderId: params.orderId,
    usedAt: new Date().toISOString(),
    discountApplied: params.discountApplied
  };

  const updatedUsedBy = [...(coupon.usedBy || []), newRecord];
  await updateCoupon(coupon.id, {
    usesCount: (coupon.usesCount || 0) + 1,
    usedBy: updatedUsedBy
  });
  return true;
}

export async function rollbackCouponUsage(params: {
  couponCode: string;
  orderId: string;
}): Promise<boolean> {
  const coupon = await getCouponByCode(params.couponCode);
  if (!coupon) return false;

  const filtered = (coupon.usedBy || []).filter(u => u.orderId !== params.orderId);
  const newCount = Math.max(0, (coupon.usesCount || 1) - 1);

  await updateCoupon(coupon.id, {
    usesCount: newCount,
    usedBy: filtered
  });
  return true;
}
