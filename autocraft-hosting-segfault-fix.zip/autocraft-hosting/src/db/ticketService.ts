import { getDatabase } from './sqlite';
import { AdminSupportTicket, AdminTicketMessage } from '../types';

function rowToTicket(row: any): AdminSupportTicket {
  let messages: AdminTicketMessage[] = [];
  try {
    messages = JSON.parse(row.messages || '[]');
  } catch {
    messages = [];
  }

  return {
    id: row.id,
    subject: row.subject,
    category: row.category || 'Technical Support',
    relatedPlan: row.relatedPlan || '',
    status: row.status || 'open',
    priority: row.priority || 'medium',
    assignedTo: row.assignedTo || 'Unassigned',
    userName: row.userName || 'User',
    userEmail: row.userEmail || '',
    createdAt: row.createdAt || new Date().toISOString(),
    lastUpdated: row.lastUpdated || new Date().toISOString(),
    messages
  };
}

export async function getAllTickets(): Promise<AdminSupportTicket[]> {
  const db = getDatabase();
  const rows = db.prepare('SELECT * FROM tickets ORDER BY lastUpdated DESC').all();
  return rows.map(rowToTicket);
}

export async function getUserTickets(userEmail: string): Promise<AdminSupportTicket[]> {
  if (!userEmail) return [];
  const db = getDatabase();
  const rows = db.prepare('SELECT * FROM tickets WHERE lower(userEmail) = ? ORDER BY lastUpdated DESC').all(userEmail.trim().toLowerCase());
  return rows.map(rowToTicket);
}

export async function getTicketById(id: string): Promise<AdminSupportTicket | null> {
  const db = getDatabase();
  const row = db.prepare('SELECT * FROM tickets WHERE id = ?').get(id);
  return row ? rowToTicket(row) : null;
}

export async function createTicket(ticket: AdminSupportTicket): Promise<AdminSupportTicket> {
  const db = getDatabase();
  const id = ticket.id || `TKT-${Math.floor(Math.random() * 90000) + 10000}`;
  const messagesJson = JSON.stringify(ticket.messages || []);

  const stmt = db.prepare(`
    INSERT INTO tickets (
      id, subject, category, relatedPlan, status, priority, assignedTo,
      userName, userEmail, userId, createdAt, lastUpdated, messages
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?,
      ?, ?, ?, ?, ?, ?
    )
  `);

  stmt.run(
    id,
    ticket.subject,
    ticket.category || 'Technical Support',
    ticket.relatedPlan || '',
    ticket.status || 'open',
    ticket.priority || 'medium',
    ticket.assignedTo || 'Unassigned',
    ticket.userName || '',
    (ticket.userEmail || '').trim().toLowerCase(),
    (ticket as any).userId || '',
    ticket.createdAt || new Date().toISOString(),
    ticket.lastUpdated || new Date().toISOString(),
    messagesJson
  );

  return (await getTicketById(id))!;
}

export async function updateTicket(id: string, updates: Partial<AdminSupportTicket>): Promise<AdminSupportTicket | null> {
  const db = getDatabase();
  const current = await getTicketById(id);
  if (!current) return null;

  const merged = { ...current, ...updates };
  const messagesJson = JSON.stringify(merged.messages || []);

  const stmt = db.prepare(`
    UPDATE tickets SET
      subject = ?,
      category = ?,
      relatedPlan = ?,
      status = ?,
      priority = ?,
      assignedTo = ?,
      lastUpdated = datetime('now'),
      messages = ?
    WHERE id = ?
  `);

  stmt.run(
    merged.subject,
    merged.category,
    merged.relatedPlan || '',
    merged.status,
    merged.priority,
    merged.assignedTo || 'Unassigned',
    messagesJson,
    id
  );

  return await getTicketById(id);
}

export async function deleteTicket(id: string): Promise<boolean> {
  const db = getDatabase();
  db.prepare('DELETE FROM tickets WHERE id = ?').run(id);
  return true;
}

export async function syncAllTickets(ticketsList: AdminSupportTicket[]): Promise<AdminSupportTicket[]> {
  const db = getDatabase();
  const syncTx = db.transaction((list: AdminSupportTicket[]) => {
    const upsertStmt = db.prepare(`
      INSERT INTO tickets (
        id, subject, category, relatedPlan, status, priority, assignedTo,
        userName, userEmail, userId, createdAt, lastUpdated, messages
      ) VALUES (
        ?, ?, ?, ?, ?, ?, ?,
        ?, ?, ?, ?, ?, ?
      )
      ON CONFLICT(id) DO UPDATE SET
        subject = excluded.subject,
        category = excluded.category,
        relatedPlan = excluded.relatedPlan,
        status = excluded.status,
        priority = excluded.priority,
        assignedTo = excluded.assignedTo,
        lastUpdated = excluded.lastUpdated,
        messages = excluded.messages
    `);

    for (const t of list) {
      upsertStmt.run(
        t.id,
        t.subject,
        t.category || 'Technical Support',
        t.relatedPlan || '',
        t.status || 'open',
        t.priority || 'medium',
        t.assignedTo || 'Unassigned',
        t.userName || '',
        (t.userEmail || '').trim().toLowerCase(),
        (t as any).userId || '',
        t.createdAt || new Date().toISOString(),
        t.lastUpdated || new Date().toISOString(),
        JSON.stringify(t.messages || [])
      );
    }
  });

  syncTx(ticketsList);
  return await getAllTickets();
}
