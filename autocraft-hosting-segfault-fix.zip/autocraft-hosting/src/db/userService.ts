import { getDatabase } from './sqlite';
import { AdminUser } from '../types';
import crypto from 'crypto';

function uint8ArrayToHex(buf: Buffer | Uint8Array): string {
  return Buffer.from(buf).toString('hex');
}

export function hashPassword(password: string, saltHex?: string): { hash: string; salt: string } {
  const salt = saltHex ? Buffer.from(saltHex, 'hex') : crypto.randomBytes(16);
  const hashBuf = crypto.pbkdf2Sync(password, salt, 100000, 32, 'sha256');
  return {
    hash: hashBuf.toString('hex'),
    salt: salt.toString('hex')
  };
}

export function verifyPassword(password: string, storedHash: string, saltHex: string): boolean {
  try {
    const { hash } = hashPassword(password, saltHex);
    return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(storedHash, 'hex'));
  } catch (err) {
    return false;
  }
}

export function generateToken(): string {
  return crypto.randomBytes(24).toString('hex');
}

function rowToUser(row: any): AdminUser {
  let roles: string[] = [];
  try {
    roles = JSON.parse(row.roles || '[]');
  } catch {
    roles = [row.role || 'User'];
  }

  return {
    id: row.id,
    name: row.name,
    username: row.username,
    email: row.email,
    role: row.role || 'User',
    roles,
    status: (row.status === 'suspended' || row.status === 'banned') ? row.status : 'active',
    joinedDate: row.joinedDate || '',
    serversCount: Number(row.serversCount) || 0,
    passwordHash: row.passwordHash || '',
    salt: row.salt || '',
    lastLogin: row.lastLogin || undefined
  };
}

export async function getAllUsers(): Promise<AdminUser[]> {
  const db = getDatabase();
  const rows = db.prepare('SELECT * FROM users ORDER BY createdAt DESC').all();
  return rows.map(rowToUser);
}

export async function getUserById(id: string): Promise<AdminUser | null> {
  const db = getDatabase();
  const row = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  return row ? rowToUser(row) : null;
}

export async function getUserByEmailOrUsername(identifier: string): Promise<AdminUser | null> {
  const db = getDatabase();
  const clean = identifier.trim().toLowerCase();
  const row = db.prepare('SELECT * FROM users WHERE lower(email) = ? OR lower(username) = ?').get(clean, clean);
  return row ? rowToUser(row) : null;
}

export async function createUser(data: {
  name: string;
  username: string;
  email: string;
  password?: string;
  passwordHash?: string;
  salt?: string;
  role?: string;
  roles?: string[];
  status?: string;
}): Promise<AdminUser> {
  const db = getDatabase();
  const id = `usr-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 7)}`;
  const cleanName = data.name.trim();
  const cleanUsername = data.username.trim().toLowerCase();
  const cleanEmail = data.email.trim().toLowerCase();
  const role = data.role || 'User';
  const roles = JSON.stringify(data.roles && data.roles.length > 0 ? data.roles : [role]);
  const status = data.status || 'active';
  const joinedDate = new Date().toISOString().substring(0, 10);

  let pHash = data.passwordHash || '';
  let salt = data.salt || '';
  if (data.password && (!pHash || !salt)) {
    const hashed = hashPassword(data.password);
    pHash = hashed.hash;
    salt = hashed.salt;
  }

  const stmt = db.prepare(`
    INSERT INTO users (
      id, name, username, email, role, roles, status, joinedDate, serversCount, passwordHash, salt, lastLogin, updatedAt
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, datetime('now'), datetime('now')
    )
  `);

  stmt.run(id, cleanName, cleanUsername, cleanEmail, role, roles, status, joinedDate, pHash, salt);
  return (await getUserById(id))!;
}

export async function updateUser(id: string, updates: Partial<AdminUser> & { password?: string }): Promise<AdminUser | null> {
  const db = getDatabase();
  const current = await getUserById(id);
  if (!current) return null;

  let pHash = current.passwordHash;
  let salt = current.salt;
  if (updates.password && updates.password.trim()) {
    const hashed = hashPassword(updates.password);
    pHash = hashed.hash;
    salt = hashed.salt;
  } else if (updates.passwordHash && updates.salt) {
    pHash = updates.passwordHash;
    salt = updates.salt;
  }

  const name = updates.name !== undefined ? updates.name.trim() : current.name;
  const username = updates.username !== undefined ? updates.username.trim().toLowerCase() : current.username;
  const email = updates.email !== undefined ? updates.email.trim().toLowerCase() : current.email;
  const role = updates.role !== undefined ? updates.role : current.role;
  const roles = JSON.stringify(updates.roles !== undefined ? updates.roles : current.roles);
  const status = updates.status !== undefined ? updates.status : current.status;
  const serversCount = updates.serversCount !== undefined ? Number(updates.serversCount) : current.serversCount;
  const lastLogin = updates.lastLogin !== undefined ? updates.lastLogin : (current.lastLogin || null);

  const stmt = db.prepare(`
    UPDATE users SET
      name = ?, username = ?, email = ?, role = ?, roles = ?, status = ?,
      serversCount = ?, passwordHash = ?, salt = ?, lastLogin = ?, updatedAt = datetime('now')
    WHERE id = ?
  `);

  stmt.run(name, username, email, role, roles, status, serversCount, pHash, salt, lastLogin, id);
  return await getUserById(id);
}

export async function deleteUser(id: string): Promise<boolean> {
  const db = getDatabase();
  db.prepare('DELETE FROM users WHERE id = ?').run(id);
  return true;
}

export async function authenticateUser(identifier: string, password: string): Promise<{
  success: boolean;
  user?: AdminUser;
  token?: string;
  error?: string;
}> {
  const cleanId = (identifier || '').trim().toLowerCase();
  if (!cleanId || !password) {
    return { success: false, error: 'Please provide both username/email and password.' };
  }

  const user = await getUserByEmailOrUsername(cleanId);
  if (!user) {
    return { success: false, error: 'Invalid username/email or password.' };
  }

  if (user.status === 'suspended') {
    return { success: false, error: 'Your account has been suspended. Please contact support.' };
  }

  if (user.status === 'banned') {
    return { success: false, error: 'Your account has been banned due to terms violation.' };
  }

  const isValid = verifyPassword(password, user.passwordHash || '', user.salt || '');
  if (!isValid) {
    return { success: false, error: 'Invalid username/email or password.' };
  }

  // Update lastLogin
  const db = getDatabase();
  db.prepare("UPDATE users SET lastLogin = datetime('now') WHERE id = ?").run(user.id);
  user.lastLogin = new Date().toISOString();

  const token = generateToken();
  return { success: true, user, token };
}
