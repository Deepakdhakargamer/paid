import { getDatabase } from './sqlite';
import { AdminOrder } from '../types';

function rowToOrder(row: any): AdminOrder {
  return {
    id: row.id,
    userId: row.userId,
    userName: row.userName || 'Customer',
    userEmail: row.userEmail || '',
    planId: row.planId || '',
    planName: row.planName || '',
    categoryId: row.categoryId || 'vps',
    categoryName: row.categoryName || 'Hosting Plan',
    price: Number(row.price) || 0,
    currency: row.currency || 'INR',
    originalPrice: Number(row.originalPrice) || Number(row.price) || 0,
    discountAmount: Number(row.discountAmount) || 0,
    couponCode: row.couponCode || undefined,
    totalAmount: Number(row.totalAmount) || Number(row.price) || 0,
    status: (row.status === 'approved' || row.status === 'rejected') ? row.status : 'pending_verification',
    screenshotUrl: row.screenshotUrl || '',
    transactionId: row.transactionId || '',
    adminNote: row.adminNote || undefined,
    rejectionReason: row.rejectionReason || undefined,
    createdAt: row.createdAt || new Date().toISOString(),
    updatedAt: row.updatedAt || new Date().toISOString()
  };
}

export async function getAllOrders(): Promise<AdminOrder[]> {
  const db = getDatabase();
  const rows = db.prepare('SELECT * FROM orders ORDER BY createdAt DESC').all();
  return rows.map(rowToOrder);
}

export async function getUserOrders(userId: string): Promise<AdminOrder[]> {
  if (!userId || !userId.trim()) return [];
  const db = getDatabase();
  const rows = db.prepare('SELECT * FROM orders WHERE userId = ? ORDER BY createdAt DESC').all(userId.trim());
  return rows.map(rowToOrder);
}

export async function getOrderById(id: string): Promise<AdminOrder | null> {
  const db = getDatabase();
  const row = db.prepare('SELECT * FROM orders WHERE id = ?').get(id);
  return row ? rowToOrder(row) : null;
}

export async function createOrder(data: Partial<AdminOrder> & { planId: string; userId: string; price: number }): Promise<AdminOrder> {
  const db = getDatabase();
  const id = data.id || `ORD-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;

  const stmt = db.prepare(`
    INSERT INTO orders (
      id, userId, userName, userEmail, planId, planName, categoryId, categoryName,
      price, currency, originalPrice, discountAmount, couponCode, totalAmount,
      status, screenshotUrl, transactionId, adminNote, rejectionReason, createdAt, updatedAt
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?, ?,
      ?, ?, ?, ?, ?, ?,
      ?, ?, ?, ?, ?, datetime('now'), datetime('now')
    )
  `);

  stmt.run(
    id,
    data.userId.trim(),
    (data.userName || 'Customer').trim(),
    (data.userEmail || '').trim().toLowerCase(),
    data.planId || '',
    data.planName || 'Hosting Plan',
    data.categoryId || 'vps',
    data.categoryName || 'Hosting Plan',
    Number(data.price) || 0,
    data.currency || 'INR',
    Number(data.originalPrice) || Number(data.price) || 0,
    Number(data.discountAmount) || 0,
    data.couponCode ? data.couponCode.trim().toUpperCase() : null,
    Number(data.totalAmount) || Number(data.price) || 0,
    data.status || 'pending_verification',
    data.screenshotUrl || '',
    data.transactionId || '',
    data.adminNote || null,
    data.rejectionReason || null
  );

  return (await getOrderById(id))!;
}

export async function updateOrder(id: string, updates: Partial<AdminOrder>): Promise<AdminOrder | null> {
  const db = getDatabase();
  const current = await getOrderById(id);
  if (!current) return null;

  const merged = { ...current, ...updates };

  const stmt = db.prepare(`
    UPDATE orders SET
      status = ?,
      adminNote = ?,
      rejectionReason = ?,
      transactionId = ?,
      screenshotUrl = ?,
      updatedAt = datetime('now')
    WHERE id = ?
  `);

  stmt.run(
    merged.status,
    merged.adminNote || null,
    merged.rejectionReason || null,
    merged.transactionId || '',
    merged.screenshotUrl || '',
    id
  );

  return await getOrderById(id);
}

export async function deleteOrder(id: string): Promise<boolean> {
  const db = getDatabase();
  db.prepare('DELETE FROM orders WHERE id = ?').run(id);
  return true;
}

export async function syncAllOrders(ordersList: AdminOrder[]): Promise<AdminOrder[]> {
  const db = getDatabase();
  const syncTx = db.transaction((list: AdminOrder[]) => {
    const upsertStmt = db.prepare(`
      INSERT INTO orders (
        id, userId, userName, userEmail, planId, planName, categoryId, categoryName,
        price, currency, originalPrice, discountAmount, couponCode, totalAmount,
        status, screenshotUrl, transactionId, adminNote, rejectionReason, createdAt, updatedAt
      ) VALUES (
        ?, ?, ?, ?, ?, ?, ?, ?,
        ?, ?, ?, ?, ?, ?,
        ?, ?, ?, ?, ?, ?, datetime('now')
      )
      ON CONFLICT(id) DO UPDATE SET
        userId = excluded.userId,
        userName = excluded.userName,
        userEmail = excluded.userEmail,
        planId = excluded.planId,
        planName = excluded.planName,
        categoryId = excluded.categoryId,
        categoryName = excluded.categoryName,
        price = excluded.price,
        currency = excluded.currency,
        originalPrice = excluded.originalPrice,
        discountAmount = excluded.discountAmount,
        couponCode = excluded.couponCode,
        totalAmount = excluded.totalAmount,
        status = excluded.status,
        screenshotUrl = excluded.screenshotUrl,
        transactionId = excluded.transactionId,
        adminNote = excluded.adminNote,
        rejectionReason = excluded.rejectionReason,
        updatedAt = datetime('now')
    `);

    for (const o of list) {
      upsertStmt.run(
        o.id,
        o.userId,
        o.userName,
        o.userEmail,
        o.planId,
        o.planName,
        o.categoryId,
        o.categoryName,
        o.price,
        o.currency || 'INR',
        o.originalPrice || o.price,
        o.discountAmount || 0,
        o.couponCode || null,
        o.totalAmount || o.price,
        o.status,
        o.screenshotUrl || '',
        o.transactionId || '',
        o.adminNote || null,
        o.rejectionReason || null,
        o.createdAt || new Date().toISOString()
      );
    }
  });

  syncTx(ordersList);
  return await getAllOrders();
}
