import { getDatabase } from './sqlite';
import { PaymentSettings } from '../utils/paymentSync';

export async function getPaymentSettings(): Promise<PaymentSettings> {
  const db = getDatabase();
  const row = db.prepare('SELECT * FROM payment_settings WHERE id = ?').get('current') as any;
  if (!row) {
    return {
      upiId: 'billing@autocraft.io',
      qrCodeUrl: 'https://api.qrserver.com/v1/create-qr-code/?data=upi%3A%2F%2Fpay%3Fpa%3Dbilling%40autocraft.io%26pn%3DAUTOCRAFT%26cu%3DINR&size=300x300',
      paymentMethod: 'both'
    };
  }

  return {
    upiId: row.upiId || 'billing@autocraft.io',
    qrCodeUrl: row.qrCodeUrl || '',
    paymentMethod: row.paymentMethod || 'both'
  };
}

export async function updatePaymentSettings(settings: Partial<PaymentSettings>): Promise<PaymentSettings> {
  const db = getDatabase();
  const current = await getPaymentSettings();
  const merged: PaymentSettings = {
    ...current,
    ...settings
  };

  const stmt = db.prepare(`
    INSERT INTO payment_settings (id, upiId, qrCodeUrl, paymentMethod, updatedAt)
    VALUES ('current', ?, ?, ?, datetime('now'))
    ON CONFLICT(id) DO UPDATE SET
      upiId = excluded.upiId,
      qrCodeUrl = excluded.qrCodeUrl,
      paymentMethod = excluded.paymentMethod,
      updatedAt = datetime('now')
  `);

  stmt.run(
    merged.upiId,
    merged.qrCodeUrl,
    merged.paymentMethod
  );

  return merged;
}
