import { get, set } from 'idb-keyval';
import { AdminCoupon, CouponUsageRecord } from '../types';
import {
  fetchCouponsFromDb,
  saveCouponToDb,
  updateCouponInDb,
  deleteCouponFromDb,
  validateCouponInDb
} from './databaseClient';

const STORAGE_KEY = 'autocraft_coupons';

const INITIAL_COUPONS: AdminCoupon[] = [
  {
    id: 'cpn-welcome10',
    code: 'WELCOME10',
    description: 'Welcome bonus 10% off for all hosting servers',
    discountType: 'percentage',
    discountValue: 10,
    minOrderAmount: 100,
    maxDiscountAmount: 100,
    usageLimit: 100,
    perUserLimit: 1,
    startDate: '2026-01-01',
    expiryDate: '2026-12-31',
    active: true,
    usesCount: 0,
    usedBy: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'cpn-astro20',
    code: 'ASTRO20',
    description: 'Special 20% discount on cloud VPS & game servers',
    discountType: 'percentage',
    discountValue: 20,
    minOrderAmount: 200,
    maxDiscountAmount: 400,
    usageLimit: 50,
    perUserLimit: 1,
    startDate: '2026-01-01',
    expiryDate: '2026-12-31',
    active: true,
    usesCount: 0,
    usedBy: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'cpn-flat100',
    code: 'FLAT100',
    description: 'Instant flat ₹100 off on high-performance plans',
    discountType: 'fixed',
    discountValue: 100,
    minOrderAmount: 400,
    usageLimit: 30,
    perUserLimit: 1,
    startDate: '2026-01-01',
    expiryDate: '2026-12-31',
    active: true,
    usesCount: 0,
    usedBy: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'cpn-expired50',
    code: 'EXPIRED50',
    description: 'Expired test promotion coupon',
    discountType: 'percentage',
    discountValue: 50,
    minOrderAmount: 100,
    usageLimit: 10,
    perUserLimit: 1,
    startDate: '2025-01-01',
    expiryDate: '2025-12-31',
    active: true,
    usesCount: 0,
    usedBy: [],
    createdAt: new Date('2025-01-01').toISOString(),
    updatedAt: new Date('2025-01-01').toISOString()
  }
];

let memoryCouponsCache: AdminCoupon[] | null = null;

// Initial fetch from SQLite on startup
if (typeof window !== 'undefined') {
  fetchCouponsFromDb().then(dbCoupons => {
    if (Array.isArray(dbCoupons) && dbCoupons.length > 0) {
      memoryCouponsCache = dbCoupons;
      set(STORAGE_KEY, dbCoupons).catch(() => {});
      window.dispatchEvent(new CustomEvent('autocraft_coupons_changed', { detail: dbCoupons }));
    }
  }).catch(() => {});
}

export const getStoredCoupons = async (): Promise<AdminCoupon[]> => {
  // 1. Try server SQLite DB
  try {
    const dbCoupons = await fetchCouponsFromDb();
    if (Array.isArray(dbCoupons) && dbCoupons.length > 0) {
      memoryCouponsCache = dbCoupons;
      await set(STORAGE_KEY, dbCoupons).catch(() => {});
      return dbCoupons;
    }
  } catch {
    // Network fallback
  }

  // 2. Memory cache fallback
  if (memoryCouponsCache && memoryCouponsCache.length > 0) {
    return memoryCouponsCache;
  }

  // 3. IndexedDB fallback
  try {
    const data = await get(STORAGE_KEY);
    if (data && Array.isArray(data) && data.length > 0) {
      memoryCouponsCache = data;
      return data;
    }
  } catch (err) {
    console.error('Error fetching coupons from storage', err);
  }

  return INITIAL_COUPONS;
};

export const saveStoredCoupons = async (coupons: AdminCoupon[]): Promise<void> => {
  memoryCouponsCache = coupons;
  try {
    await set(STORAGE_KEY, coupons);
    window.dispatchEvent(new CustomEvent('autocraft_coupons_changed', { detail: coupons }));
  } catch (err) {
    console.error('Error saving coupons to storage', err);
  }
};

export const createCoupon = async (
  couponData: Omit<AdminCoupon, 'id' | 'usesCount' | 'usedBy' | 'createdAt' | 'updatedAt'>
): Promise<{ success: boolean; coupon?: AdminCoupon; error?: string }> => {
  try {
    const cleanCode = couponData.code.trim().toUpperCase();
    if (!cleanCode) {
      return { success: false, error: 'Coupon code cannot be empty.' };
    }

    if (couponData.discountValue <= 0) {
      return { success: false, error: 'Discount value must be greater than zero.' };
    }

    if (couponData.discountType === 'percentage' && couponData.discountValue > 100) {
      return { success: false, error: 'Percentage discount cannot exceed 100%.' };
    }

    // 1. Save to SQLite DB
    const saved = await saveCouponToDb({
      ...couponData,
      code: cleanCode
    });

    if (saved) {
      const current = await getStoredCoupons();
      await saveStoredCoupons([saved, ...current.filter(c => c.id !== saved.id)]);
      return { success: true, coupon: saved };
    }

    // Local fallback
    const coupons = await getStoredCoupons();
    if (coupons.some(c => c.code.toUpperCase() === cleanCode)) {
      return { success: false, error: `Coupon code "${cleanCode}" already exists.` };
    }

    const newCoupon: AdminCoupon = {
      ...couponData,
      id: 'cpn-' + Date.now().toString(36) + '-' + Math.random().toString(36).substring(2, 7),
      code: cleanCode,
      usesCount: 0,
      usedBy: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const updated = [newCoupon, ...coupons];
    await saveStoredCoupons(updated);
    return { success: true, coupon: newCoupon };
  } catch (err: any) {
    return { success: false, error: err.message || 'Failed to create coupon.' };
  }
};

export const updateCoupon = async (
  id: string,
  updates: Partial<AdminCoupon>
): Promise<{ success: boolean; coupon?: AdminCoupon; error?: string }> => {
  try {
    // 1. Update in SQLite DB
    const updatedDbCoupon = await updateCouponInDb(id, updates);

    const coupons = await getStoredCoupons();
    const existingIndex = coupons.findIndex(c => c.id === id);
    if (existingIndex === -1 && !updatedDbCoupon) {
      return { success: false, error: 'Coupon not found.' };
    }

    const finalCoupon = updatedDbCoupon || {
      ...coupons[existingIndex],
      ...updates,
      updatedAt: new Date().toISOString()
    };

    const updatedList = coupons.map(c => c.id === id ? finalCoupon : c);
    await saveStoredCoupons(updatedList);
    return { success: true, coupon: finalCoupon };
  } catch (err: any) {
    return { success: false, error: err.message || 'Failed to update coupon.' };
  }
};

export const deleteCoupon = async (id: string): Promise<boolean> => {
  try {
    deleteCouponFromDb(id).catch(err => {
      console.error('Failed to delete coupon in SQLite:', err);
    });

    const coupons = await getStoredCoupons();
    const filtered = coupons.filter(c => c.id !== id);
    await saveStoredCoupons(filtered);
    return true;
  } catch (err) {
    console.error('Error deleting coupon', err);
    return false;
  }
};

export const toggleCouponStatus = async (id: string): Promise<boolean> => {
  try {
    const coupons = await getStoredCoupons();
    const coupon = coupons.find(c => c.id === id);
    if (!coupon) return false;

    const res = await updateCoupon(id, { active: !coupon.active });
    return res.success;
  } catch {
    return false;
  }
};

export interface CouponValidationResult {
  valid: boolean;
  error?: string;
  coupon?: AdminCoupon;
  discountAmount: number;
  finalPrice: number;
}

export const validateCoupon = async (params: {
  code: string;
  orderAmount: number;
  userId?: string;
}): Promise<CouponValidationResult> => {
  const { code, orderAmount, userId } = params;
  const cleanCode = (code || '').trim().toUpperCase();

  if (!cleanCode) {
    return {
      valid: false,
      error: 'Please enter a coupon code.',
      discountAmount: 0,
      finalPrice: orderAmount
    };
  }

  // 1. Try server SQLite API validation
  try {
    const apiRes = await validateCouponInDb(params);
    if (apiRes) {
      return apiRes;
    }
  } catch {
    // Local fallback check
  }

  // 2. Local fallback validation
  const coupons = await getStoredCoupons();
  const coupon = coupons.find(c => c.code.toUpperCase() === cleanCode);

  if (!coupon) {
    return {
      valid: false,
      error: 'Invalid coupon code',
      discountAmount: 0,
      finalPrice: orderAmount
    };
  }

  if (!coupon.active) {
    return {
      valid: false,
      error: 'Coupon is not active',
      discountAmount: 0,
      finalPrice: orderAmount
    };
  }

  const now = new Date();

  if (coupon.startDate) {
    const start = new Date(coupon.startDate);
    if (now < start) {
      return {
        valid: false,
        error: 'Coupon has not started yet',
        discountAmount: 0,
        finalPrice: orderAmount
      };
    }
  }

  if (coupon.expiryDate) {
    const expiry = new Date(coupon.expiryDate);
    if (coupon.expiryDate.length === 10) {
      expiry.setHours(23, 59, 59, 999);
    }
    if (now > expiry) {
      return {
        valid: false,
        error: 'Coupon has expired',
        discountAmount: 0,
        finalPrice: orderAmount
      };
    }
  }

  if (coupon.usageLimit && coupon.usageLimit > 0) {
    if (coupon.usesCount >= coupon.usageLimit) {
      return {
        valid: false,
        error: 'Coupon usage limit has been reached',
        discountAmount: 0,
        finalPrice: orderAmount
      };
    }
  }

  if (userId && coupon.perUserLimit && coupon.perUserLimit > 0) {
    const userUses = (coupon.usedBy || []).filter(u => u.userId === userId).length;
    if (userUses >= coupon.perUserLimit) {
      return {
        valid: false,
        error: `You have already used this coupon the maximum allowed times (${coupon.perUserLimit}).`,
        discountAmount: 0,
        finalPrice: orderAmount
      };
    }
  }

  if (coupon.minOrderAmount && coupon.minOrderAmount > 0) {
    if (orderAmount < coupon.minOrderAmount) {
      return {
        valid: false,
        error: `Minimum order amount for this coupon is ₹${coupon.minOrderAmount}.`,
        discountAmount: 0,
        finalPrice: orderAmount
      };
    }
  }

  let calculatedDiscount = 0;
  if (coupon.discountType === 'percentage') {
    calculatedDiscount = (orderAmount * coupon.discountValue) / 100;
    if (coupon.maxDiscountAmount && coupon.maxDiscountAmount > 0) {
      calculatedDiscount = Math.min(calculatedDiscount, coupon.maxDiscountAmount);
    }
  } else {
    calculatedDiscount = coupon.discountValue;
  }

  calculatedDiscount = Math.min(calculatedDiscount, orderAmount);
  calculatedDiscount = Math.round(calculatedDiscount * 100) / 100;

  const finalPrice = Math.max(0, Math.round((orderAmount - calculatedDiscount) * 100) / 100);

  return {
    valid: true,
    coupon,
    discountAmount: calculatedDiscount,
    finalPrice
  };
};

export const recordCouponUsage = async (params: {
  couponId?: string;
  couponCode?: string;
  orderId: string;
  userId?: string;
  userEmail?: string;
  discountApplied: number;
}): Promise<boolean> => {
  const coupons = await getStoredCoupons();
  let coupon = coupons.find(c => c.id === params.couponId || c.code.toUpperCase() === (params.couponCode || '').toUpperCase());
  if (!coupon) return false;

  const newRecord: CouponUsageRecord = {
    userId: params.userId || 'guest',
    userEmail: params.userEmail,
    orderId: params.orderId,
    usedAt: new Date().toISOString(),
    discountApplied: params.discountApplied
  };

  const updatedUsedBy = [...(coupon.usedBy || []), newRecord];
  await updateCoupon(coupon.id, {
    usesCount: (coupon.usesCount || 0) + 1,
    usedBy: updatedUsedBy
  });
  return true;
};

export const rollbackCouponUsage = async (params: {
  couponCode: string;
  orderId: string;
}): Promise<boolean> => {
  const coupons = await getStoredCoupons();
  const coupon = coupons.find(c => c.code.toUpperCase() === params.couponCode.toUpperCase());
  if (!coupon) return false;

  const filtered = (coupon.usedBy || []).filter(u => u.orderId !== params.orderId);
  const newCount = Math.max(0, (coupon.usesCount || 1) - 1);

  await updateCoupon(coupon.id, {
    usesCount: newCount,
    usedBy: filtered
  });
  return true;
};
