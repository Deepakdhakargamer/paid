import { fetchPaymentSettingsFromDb, savePaymentSettingsToDb } from './databaseClient';

export interface PaymentSettings {
  upiId: string;
  qrCodeUrl: string;
  paymentMethod: 'upi' | 'card' | 'both';
}

const STORAGE_KEY = 'autocraft_payment_settings';

export const INITIAL_PAYMENT_SETTINGS: PaymentSettings = {
  upiId: 'billing@autocraft.io',
  qrCodeUrl: 'https://api.qrserver.com/v1/create-qr-code/?data=upi%3A%2F%2Fpay%3Fpa%3Dbilling%40autocraft.io%26pn%3DAUTOCRAFT%26cu%3DINR&size=300x300',
  paymentMethod: 'both'
};

let memoryPaymentSettingsCache: PaymentSettings | null = null;

// Bootstrap from SQLite on startup
if (typeof window !== 'undefined') {
  fetchPaymentSettingsFromDb().then(dbSettings => {
    if (dbSettings) {
      memoryPaymentSettingsCache = dbSettings;
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(dbSettings));
      } catch {}
      window.dispatchEvent(new CustomEvent('autocraft_payment_changed', { detail: dbSettings }));
    }
  }).catch(() => {});
}

export function getStoredPaymentSettings(): PaymentSettings {
  if (memoryPaymentSettingsCache) {
    return memoryPaymentSettingsCache;
  }

  try {
    const item = typeof localStorage !== 'undefined' ? localStorage.getItem(STORAGE_KEY) : null;
    if (item) {
      const parsed = JSON.parse(item);
      memoryPaymentSettingsCache = parsed;
      return parsed;
    }
  } catch (e) {
    console.warn('Error reading payment settings from localStorage', e);
  }
  return INITIAL_PAYMENT_SETTINGS;
}

export function saveStoredPaymentSettings(settings: PaymentSettings): void {
  memoryPaymentSettingsCache = settings;
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
    }
    window.dispatchEvent(new CustomEvent('autocraft_payment_changed', { detail: settings }));
  } catch (e) {
    console.warn('Error saving payment settings to localStorage', e);
  }

  // Persist to server SQLite
  savePaymentSettingsToDb(settings).catch(err => {
    console.error('Failed to save payment settings to SQLite:', err);
  });
}
