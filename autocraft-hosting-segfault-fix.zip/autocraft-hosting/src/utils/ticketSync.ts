import { AdminSupportTicket } from '../types';
import { fetchTicketsFromDb, saveTicketToDb, updateTicketInDb } from './databaseClient';

const STORAGE_KEY = 'autocraft_tickets';

export const INITIAL_TICKETS: AdminSupportTicket[] = [];

let memoryTicketsCache: AdminSupportTicket[] | null = null;

// Initial fetch from SQLite on startup
if (typeof window !== 'undefined') {
  fetchTicketsFromDb().then(dbTickets => {
    if (Array.isArray(dbTickets) && dbTickets.length > 0) {
      memoryTicketsCache = dbTickets;
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(dbTickets));
      } catch {}
      window.dispatchEvent(new CustomEvent('autocraft_tickets_changed', { detail: dbTickets }));
    }
  }).catch(() => {});
}

export function getStoredTickets(): AdminSupportTicket[] {
  if (memoryTicketsCache) {
    return memoryTicketsCache;
  }

  try {
    const item = typeof localStorage !== 'undefined' ? localStorage.getItem(STORAGE_KEY) : null;
    if (item) {
      const parsed = JSON.parse(item);
      memoryTicketsCache = parsed;
      return parsed;
    }
  } catch (e) {
    console.warn('Error reading tickets from localStorage', e);
  }
  return INITIAL_TICKETS;
}

export function saveStoredTickets(tickets: AdminSupportTicket[]): void {
  memoryTicketsCache = tickets;
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(tickets));
    }
    window.dispatchEvent(new CustomEvent('autocraft_tickets_changed', { detail: tickets }));
  } catch (e) {
    console.warn('Error saving tickets to localStorage', e);
  }

  // Sync to SQLite server
  fetch('/api/tickets', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(tickets)
  }).catch(err => {
    console.error('Failed to sync tickets to SQLite:', err);
  });
}
