import { AdminOrder } from '../types';
import { get, set } from 'idb-keyval';
import { getCurrentSession, getStoredUsers } from './userSync';
import { getStoredPlans } from './planSync';
import { validateCoupon, recordCouponUsage, rollbackCouponUsage } from './couponSync';
import {
  fetchOrdersFromDb,
  saveOrderToDb,
  updateOrderInDb,
  deleteOrderFromDb,
  syncOrdersToDb
} from './databaseClient';

const STORAGE_KEY = 'autocraft_orders';

let memoryOrdersCache: AdminOrder[] | null = null;

// Initial fetch from SQLite on startup
if (typeof window !== 'undefined') {
  fetchOrdersFromDb().then(dbOrders => {
    if (Array.isArray(dbOrders) && dbOrders.length > 0) {
      memoryOrdersCache = dbOrders;
      set(STORAGE_KEY, dbOrders).catch(() => {});
      window.dispatchEvent(new CustomEvent('autocraft_orders_changed', { detail: dbOrders }));
    }
  }).catch(() => {});
}

export const getStoredOrders = async (): Promise<AdminOrder[]> => {
  // 1. Try server SQLite DB
  try {
    const dbOrders = await fetchOrdersFromDb();
    if (Array.isArray(dbOrders)) {
      memoryOrdersCache = dbOrders;
      await set(STORAGE_KEY, dbOrders).catch(() => {});
      return dbOrders;
    }
  } catch {
    // Network fallback
  }

  // 2. Memory cache fallback
  if (memoryOrdersCache) {
    return memoryOrdersCache;
  }

  // 3. IndexedDB fallback
  try {
    const rawOrders: AdminOrder[] = (await get(STORAGE_KEY)) || [];
    if (Array.isArray(rawOrders)) {
      memoryOrdersCache = rawOrders;
      return rawOrders;
    }
  } catch (err) {
    console.error('Error fetching orders from IndexedDB', err);
  }

  return [];
};

export const getUserOrders = async (userId: string): Promise<AdminOrder[]> => {
  if (!userId || typeof userId !== 'string' || !userId.trim()) {
    return [];
  }
  const cleanUserId = userId.trim();

  // 1. Fetch from server SQLite DB for this user
  try {
    const dbOrders = await fetchOrdersFromDb(cleanUserId);
    if (Array.isArray(dbOrders)) {
      return dbOrders.filter(o => o.userId === cleanUserId);
    }
  } catch {
    // Fallback
  }

  // 2. Fallback to all stored orders filter
  const allOrders = await getStoredOrders();
  return allOrders.filter(order => 
    Boolean(order && order.userId && typeof order.userId === 'string' && order.userId.trim() === cleanUserId)
  );
};

export const saveStoredOrders = async (orders: AdminOrder[]) => {
  memoryOrdersCache = orders;
  try {
    await set(STORAGE_KEY, orders);
    window.dispatchEvent(new CustomEvent('autocraft_orders_changed', { detail: orders }));
  } catch (err) {
    console.error('Error saving orders to storage', err);
  }
};

export const updateStoredOrders = async (orders: AdminOrder[]) => {
  // Sync to server SQLite database
  syncOrdersToDb(orders).catch(err => {
    console.error('Failed to sync orders to SQLite:', err);
  });

  await saveStoredOrders(orders);
};

export const addOrder = async (order: Partial<AdminOrder> & { planId: string; planName: string; price: number }): Promise<{ success: boolean; order?: AdminOrder; error?: string }> => {
  // Validate active session
  const session = getCurrentSession();
  if (!session || !session.user || !session.user.id) {
    throw new Error('Authentication required: Please login or register to purchase a plan.');
  }

  const authenticatedUser = session.user;

  // Authoritatively verify plan and base price
  const plans = getStoredPlans();
  const dbPlan = plans.find(p => p.id === order.planId);
  const basePlanPrice = dbPlan ? dbPlan.price : (order.originalPrice || order.price);

  let verifiedOriginalPrice = basePlanPrice;
  let verifiedDiscountAmount = 0;
  let verifiedFinalPrice = basePlanPrice;
  let verifiedCouponCode: string | undefined = undefined;
  let validatedCouponId: string | undefined = undefined;

  // Validate coupon authoritatively
  if (order.couponCode && order.couponCode.trim()) {
    const cleanCouponCode = order.couponCode.trim().toUpperCase();
    const validation = await validateCoupon({
      code: cleanCouponCode,
      orderAmount: basePlanPrice,
      userId: authenticatedUser.id
    });

    if (!validation.valid || !validation.coupon) {
      throw new Error(validation.error || 'Invalid coupon code.');
    }

    verifiedCouponCode = validation.coupon.code;
    validatedCouponId = validation.coupon.id;
    verifiedDiscountAmount = validation.discountAmount;
    verifiedFinalPrice = validation.finalPrice;
  }

  const newOrder: AdminOrder = {
    id: 'ORD-' + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).substring(2, 7).toUpperCase(),
    userId: authenticatedUser.id,
    userName: authenticatedUser.name,
    userEmail: authenticatedUser.email,
    planId: order.planId,
    planName: dbPlan ? dbPlan.name : order.planName,
    categoryId: dbPlan ? dbPlan.categoryId : (order.categoryId || 'vps'),
    categoryName: order.categoryName || 'Hosting Plan',
    price: verifiedFinalPrice,
    currency: 'INR',
    originalPrice: verifiedOriginalPrice,
    discountAmount: verifiedDiscountAmount,
    couponCode: verifiedCouponCode,
    totalAmount: verifiedFinalPrice,
    screenshotUrl: order.screenshotUrl || '',
    transactionId: order.transactionId || '',
    status: 'pending_verification',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    adminNote: order.adminNote,
  };

  // 1. Save to SQLite Database
  const savedDbOrder = await saveOrderToDb(newOrder);
  const finalOrder = savedDbOrder || newOrder;

  // 2. Update local state
  const currentOrders = await getStoredOrders();
  await saveStoredOrders([finalOrder, ...currentOrders.filter(o => o.id !== finalOrder.id)]);

  // 3. Record coupon usage
  if (validatedCouponId && verifiedCouponCode) {
    await recordCouponUsage({
      couponId: validatedCouponId,
      orderId: finalOrder.id,
      userId: authenticatedUser.id,
      userEmail: authenticatedUser.email,
      discountApplied: verifiedDiscountAmount
    });
  }

  return { success: true, order: finalOrder };
};

export const submitPurchaseOrder = async (orderData: {
  planId: string;
  planName: string;
  categoryId?: string;
  categoryName?: string;
  price: number;
  couponCode?: string;
  screenshotUrl: string;
  transactionId?: string;
}) => {
  return await addOrder(orderData);
};

export const updateOrder = async (orderId: string, updates: Partial<AdminOrder>) => {
  // Update in SQLite DB
  updateOrderInDb(orderId, updates).catch(err => {
    console.error('Failed to update order in SQLite:', err);
  });

  const orders = await getStoredOrders();
  const existingOrder = orders.find(o => o.id === orderId);

  // If order status is being changed to rejected, rollback coupon usage
  if (existingOrder && updates.status === 'rejected' && existingOrder.status !== 'rejected') {
    if (existingOrder.couponCode) {
      await rollbackCouponUsage({
        couponCode: existingOrder.couponCode,
        orderId: existingOrder.id
      });
    }
  }

  const updated = orders.map(o => o.id === orderId ? { ...o, ...updates, updatedAt: new Date().toISOString() } : o);
  await saveStoredOrders(updated);
};

export const deleteOrder = async (orderId: string) => {
  // Delete from SQLite DB
  deleteOrderFromDb(orderId).catch(err => {
    console.error('Failed to delete order from SQLite:', err);
  });

  const orders = await getStoredOrders();
  const existingOrder = orders.find(o => o.id === orderId);

  if (existingOrder && existingOrder.couponCode) {
    await rollbackCouponUsage({
      couponCode: existingOrder.couponCode,
      orderId: existingOrder.id
    });
  }

  const filtered = orders.filter(o => o.id !== orderId);
  await saveStoredOrders(filtered);
};
