import type { Plugin } from 'vite';
import { 
  getAllCategories, 
  getCategoryById, 
  createCategory, 
  updateCategory, 
  deleteCategory, 
  syncAllCategories,
  getAllPlans, 
  getPlanById, 
  createPlan, 
  updatePlan, 
  deletePlan, 
  syncAllPlans 
} from '../db/planCategoryService';

import {
  getAllUsers,
  getUserById,
  getUserByEmailOrUsername,
  createUser,
  updateUser,
  deleteUser,
  authenticateUser
} from '../db/userService';

import {
  getAllOrders,
  getUserOrders,
  getOrderById,
  createOrder,
  updateOrder,
  deleteOrder,
  syncAllOrders
} from '../db/orderService';

import {
  getAllCoupons,
  getCouponById,
  getCouponByCode,
  createCoupon,
  updateCoupon,
  deleteCoupon,
  validateCoupon,
  recordCouponUsage,
  rollbackCouponUsage
} from '../db/couponService';

import {
  getPaymentSettings,
  updatePaymentSettings
} from '../db/paymentService';

import {
  getAllTickets,
  getUserTickets,
  getTicketById,
  createTicket,
  updateTicket,
  deleteTicket,
  syncAllTickets
} from '../db/ticketService';

// Helper to parse JSON request bodies in standard Connect/Vite middleware
function parseJsonBody(req: any): Promise<any> {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk: any) => {
      body += chunk;
    });
    req.on('end', () => {
      if (!body) {
        resolve({});
        return;
      }
      try {
        resolve(JSON.parse(body));
      } catch (err) {
        reject(err);
      }
    });
    req.on('error', reject);
  });
}

function sendJson(res: any, statusCode: number, data: any) {
  res.statusCode = statusCode;
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.end(JSON.stringify(data));
}

export function sqliteApiPlugin(): Plugin {
  return {
    name: 'autocraft-sqlite-api',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        const url = req.url || '';
        const method = req.method || 'GET';

        if (!url.startsWith('/api/')) {
          return next();
        }

        try {
          const parsedUrl = new URL(url, 'http://localhost');
          const pathname = parsedUrl.pathname;
          const searchParams = parsedUrl.searchParams;

          // ====================================================
          // 1. /api/categories
          // ====================================================
          if (pathname === '/api/categories') {
            if (method === 'GET') {
              const categories = await getAllCategories();
              return sendJson(res, 200, { success: true, data: categories });
            }
            if (method === 'POST') {
              const body = await parseJsonBody(req);
              const created = await createCategory(body);
              return sendJson(res, 201, { success: true, data: created });
            }
            if (method === 'PUT') {
              const body = await parseJsonBody(req);
              const categories = Array.isArray(body) ? body : (body.categories || []);
              const synced = await syncAllCategories(categories);
              return sendJson(res, 200, { success: true, data: synced });
            }
          }

          const catIdMatch = pathname.match(/^\/api\/categories\/([^/]+)$/);
          if (catIdMatch) {
            const catId = decodeURIComponent(catIdMatch[1]);
            if (method === 'GET') {
              const cat = await getCategoryById(catId);
              if (!cat) return sendJson(res, 404, { success: false, error: 'Category not found' });
              return sendJson(res, 200, { success: true, data: cat });
            }
            if (method === 'PUT' || method === 'PATCH') {
              const body = await parseJsonBody(req);
              const updated = await updateCategory(catId, body);
              if (!updated) return sendJson(res, 404, { success: false, error: 'Category not found' });
              return sendJson(res, 200, { success: true, data: updated });
            }
            if (method === 'DELETE') {
              await deleteCategory(catId);
              return sendJson(res, 200, { success: true, message: 'Category deleted' });
            }
          }

          // ====================================================
          // 2. /api/plans
          // ====================================================
          if (pathname === '/api/plans') {
            if (method === 'GET') {
              const plans = await getAllPlans();
              return sendJson(res, 200, { success: true, data: plans });
            }
            if (method === 'POST') {
              const body = await parseJsonBody(req);
              const created = await createPlan(body);
              return sendJson(res, 201, { success: true, data: created });
            }
            if (method === 'PUT') {
              const body = await parseJsonBody(req);
              const plans = Array.isArray(body) ? body : (body.plans || []);
              const synced = await syncAllPlans(plans);
              return sendJson(res, 200, { success: true, data: synced });
            }
          }

          const planIdMatch = pathname.match(/^\/api\/plans\/([^/]+)$/);
          if (planIdMatch) {
            const planId = decodeURIComponent(planIdMatch[1]);
            if (method === 'GET') {
              const plan = await getPlanById(planId);
              if (!plan) return sendJson(res, 404, { success: false, error: 'Plan not found' });
              return sendJson(res, 200, { success: true, data: plan });
            }
            if (method === 'PUT' || method === 'PATCH') {
              const body = await parseJsonBody(req);
              const updated = await updatePlan(planId, body);
              if (!updated) return sendJson(res, 404, { success: false, error: 'Plan not found' });
              return sendJson(res, 200, { success: true, data: updated });
            }
            if (method === 'DELETE') {
              await deletePlan(planId);
              return sendJson(res, 200, { success: true, message: 'Plan deleted' });
            }
          }

          // ====================================================
          // 3. /api/auth & /api/users
          // ====================================================
          if (pathname === '/api/auth/login' && method === 'POST') {
            const body = await parseJsonBody(req);
            const result = await authenticateUser(body.identifier, body.password);
            if (!result.success) {
              return sendJson(res, 401, result);
            }
            return sendJson(res, 200, result);
          }

          if (pathname === '/api/auth/register' && method === 'POST') {
            const body = await parseJsonBody(req);
            const { name, username, email, password } = body;
            if (!name || !username || !email || !password) {
              return sendJson(res, 400, { success: false, error: 'All fields are required.' });
            }
            if (password.length < 6) {
              return sendJson(res, 400, { success: false, error: 'Password must be at least 6 characters.' });
            }

            const existingEmail = await getUserByEmailOrUsername(email);
            if (existingEmail) {
              return sendJson(res, 409, { success: false, error: 'An account with this email already exists.' });
            }
            const existingUsername = await getUserByEmailOrUsername(username);
            if (existingUsername) {
              return sendJson(res, 409, { success: false, error: 'This username is already taken. Please choose another.' });
            }

            const newUser = await createUser({
              name,
              username,
              email,
              password,
              role: 'User',
              roles: ['Standard User'],
              status: 'active'
            });

            return sendJson(res, 201, { success: true, user: newUser });
          }

          if (pathname === '/api/auth/verify' && method === 'POST') {
            const body = await parseJsonBody(req);
            const userId = body.userId;
            if (!userId) {
              return sendJson(res, 400, { success: false, error: 'Missing userId' });
            }
            const user = await getUserById(userId);
            if (!user || user.status === 'suspended' || user.status === 'banned') {
              return sendJson(res, 401, { success: false, error: 'Invalid or inactive user session' });
            }
            return sendJson(res, 200, { success: true, user });
          }

          if (pathname === '/api/users') {
            if (method === 'GET') {
              const users = await getAllUsers();
              return sendJson(res, 200, { success: true, data: users });
            }
            if (method === 'POST') {
              const body = await parseJsonBody(req);
              const created = await createUser(body);
              return sendJson(res, 201, { success: true, data: created });
            }
          }

          const userPassMatch = pathname.match(/^\/api\/users\/([^/]+)\/password$/);
          if (userPassMatch && method === 'POST') {
            const userId = decodeURIComponent(userPassMatch[1]);
            const body = await parseJsonBody(req);
            const updated = await updateUser(userId, { password: body.password });
            if (!updated) return sendJson(res, 404, { success: false, error: 'User not found' });
            return sendJson(res, 200, { success: true, message: 'Password updated successfully' });
          }

          const userIdMatch = pathname.match(/^\/api\/users\/([^/]+)$/);
          if (userIdMatch) {
            const userId = decodeURIComponent(userIdMatch[1]);
            if (method === 'GET') {
              const user = await getUserById(userId);
              if (!user) return sendJson(res, 404, { success: false, error: 'User not found' });
              return sendJson(res, 200, { success: true, data: user });
            }
            if (method === 'PUT' || method === 'PATCH') {
              const body = await parseJsonBody(req);
              const updated = await updateUser(userId, body);
              if (!updated) return sendJson(res, 404, { success: false, error: 'User not found' });
              return sendJson(res, 200, { success: true, data: updated });
            }
            if (method === 'DELETE') {
              await deleteUser(userId);
              return sendJson(res, 200, { success: true, message: 'User deleted' });
            }
          }

          // ====================================================
          // 4. /api/orders
          // ====================================================
          if (pathname === '/api/orders') {
            if (method === 'GET') {
              const userId = searchParams.get('userId');
              if (userId) {
                const orders = await getUserOrders(userId);
                return sendJson(res, 200, { success: true, data: orders });
              }
              const orders = await getAllOrders();
              return sendJson(res, 200, { success: true, data: orders });
            }
            if (method === 'POST') {
              const body = await parseJsonBody(req);
              if (!body.userId || !body.planId) {
                return sendJson(res, 400, { success: false, error: 'Missing required order fields: userId or planId' });
              }
              const created = await createOrder(body);
              if (created.couponCode) {
                await recordCouponUsage({
                  couponCode: created.couponCode,
                  orderId: created.id,
                  userId: created.userId,
                  userEmail: created.userEmail,
                  discountApplied: created.discountAmount
                });
              }
              return sendJson(res, 201, { success: true, data: created });
            }
            if (method === 'PUT') {
              const body = await parseJsonBody(req);
              const ordersList = Array.isArray(body) ? body : (body.orders || []);
              const synced = await syncAllOrders(ordersList);
              return sendJson(res, 200, { success: true, data: synced });
            }
          }

          const orderIdMatch = pathname.match(/^\/api\/orders\/([^/]+)$/);
          if (orderIdMatch) {
            const orderId = decodeURIComponent(orderIdMatch[1]);
            if (method === 'GET') {
              const order = await getOrderById(orderId);
              if (!order) return sendJson(res, 404, { success: false, error: 'Order not found' });
              return sendJson(res, 200, { success: true, data: order });
            }
            if (method === 'PUT' || method === 'PATCH') {
              const body = await parseJsonBody(req);
              const current = await getOrderById(orderId);
              if (!current) return sendJson(res, 404, { success: false, error: 'Order not found' });

              // If changing to rejected, rollback coupon usage
              if (body.status === 'rejected' && current.status !== 'rejected' && current.couponCode) {
                await rollbackCouponUsage({
                  couponCode: current.couponCode,
                  orderId: current.id
                });
              }

              const updated = await updateOrder(orderId, body);
              return sendJson(res, 200, { success: true, data: updated });
            }
            if (method === 'DELETE') {
              const current = await getOrderById(orderId);
              if (current && current.couponCode) {
                await rollbackCouponUsage({
                  couponCode: current.couponCode,
                  orderId: current.id
                });
              }
              await deleteOrder(orderId);
              return sendJson(res, 200, { success: true, message: 'Order deleted' });
            }
          }

          // ====================================================
          // 5. /api/coupons
          // ====================================================
          if (pathname === '/api/coupons/validate' && method === 'POST') {
            const body = await parseJsonBody(req);
            const result = await validateCoupon({
              code: body.code,
              orderAmount: Number(body.orderAmount) || 0,
              userId: body.userId
            });
            return sendJson(res, 200, { success: true, ...result });
          }

          if (pathname === '/api/coupons') {
            if (method === 'GET') {
              const coupons = await getAllCoupons();
              return sendJson(res, 200, { success: true, data: coupons });
            }
            if (method === 'POST') {
              const body = await parseJsonBody(req);
              const existing = await getCouponByCode(body.code);
              if (existing) {
                return sendJson(res, 409, { success: false, error: `Coupon "${body.code.toUpperCase()}" already exists.` });
              }
              const created = await createCoupon(body);
              return sendJson(res, 201, { success: true, data: created });
            }
          }

          const couponIdMatch = pathname.match(/^\/api\/coupons\/([^/]+)$/);
          if (couponIdMatch) {
            const couponId = decodeURIComponent(couponIdMatch[1]);
            if (method === 'GET') {
              const coupon = await getCouponById(couponId);
              if (!coupon) return sendJson(res, 404, { success: false, error: 'Coupon not found' });
              return sendJson(res, 200, { success: true, data: coupon });
            }
            if (method === 'PUT' || method === 'PATCH') {
              const body = await parseJsonBody(req);
              const updated = await updateCoupon(couponId, body);
              if (!updated) return sendJson(res, 404, { success: false, error: 'Coupon not found' });
              return sendJson(res, 200, { success: true, data: updated });
            }
            if (method === 'DELETE') {
              await deleteCoupon(couponId);
              return sendJson(res, 200, { success: true, message: 'Coupon deleted' });
            }
          }

          // ====================================================
          // 6. /api/payment-settings
          // ====================================================
          if (pathname === '/api/payment-settings') {
            if (method === 'GET') {
              const settings = await getPaymentSettings();
              return sendJson(res, 200, { success: true, data: settings });
            }
            if (method === 'PUT' || method === 'POST') {
              const body = await parseJsonBody(req);
              const updated = await updatePaymentSettings(body);
              return sendJson(res, 200, { success: true, data: updated });
            }
          }

          // ====================================================
          // 7. /api/tickets
          // ====================================================
          if (pathname === '/api/tickets') {
            if (method === 'GET') {
              const userEmail = searchParams.get('userEmail');
              if (userEmail) {
                const tickets = await getUserTickets(userEmail);
                return sendJson(res, 200, { success: true, data: tickets });
              }
              const tickets = await getAllTickets();
              return sendJson(res, 200, { success: true, data: tickets });
            }
            if (method === 'POST') {
              const body = await parseJsonBody(req);
              const created = await createTicket(body);
              return sendJson(res, 201, { success: true, data: created });
            }
            if (method === 'PUT') {
              const body = await parseJsonBody(req);
              const ticketsList = Array.isArray(body) ? body : (body.tickets || []);
              const synced = await syncAllTickets(ticketsList);
              return sendJson(res, 200, { success: true, data: synced });
            }
          }

          const ticketIdMatch = pathname.match(/^\/api\/tickets\/([^/]+)$/);
          if (ticketIdMatch) {
            const ticketId = decodeURIComponent(ticketIdMatch[1]);
            if (method === 'GET') {
              const ticket = await getTicketById(ticketId);
              if (!ticket) return sendJson(res, 404, { success: false, error: 'Ticket not found' });
              return sendJson(res, 200, { success: true, data: ticket });
            }
            if (method === 'PUT' || method === 'PATCH') {
              const body = await parseJsonBody(req);
              const updated = await updateTicket(ticketId, body);
              if (!updated) return sendJson(res, 404, { success: false, error: 'Ticket not found' });
              return sendJson(res, 200, { success: true, data: updated });
            }
            if (method === 'DELETE') {
              await deleteTicket(ticketId);
              return sendJson(res, 200, { success: true, message: 'Ticket deleted' });
            }
          }

          return sendJson(res, 404, { success: false, error: 'API route not found' });
        } catch (err: any) {
          console.error('[API Error]', err);
          return sendJson(res, 500, { success: false, error: err.message || 'Internal server error' });
        }
      });
    }
  };
}
